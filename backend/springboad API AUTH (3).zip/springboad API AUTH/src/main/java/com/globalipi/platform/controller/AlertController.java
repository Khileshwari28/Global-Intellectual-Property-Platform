package com.globalipi.platform.controller;

import com.globalipi.platform.entity.MonitoringAlert;
import com.globalipi.platform.service.AlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alerts")
@CrossOrigin(origins = "*")
public class AlertController {
    
    @Autowired
    private AlertService alertService;
    
    @GetMapping
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<MonitoringAlert>> getUserAlerts(Authentication authentication) {
        // In a real implementation, get userId from authentication
        // For now, using a placeholder
        Integer userId = 1; // TODO: Extract from authentication
        return ResponseEntity.ok(alertService.getUserAlerts(userId));
    }
    
    @GetMapping("/unread")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<MonitoringAlert>> getUnreadAlerts(Authentication authentication) {
        Integer userId = 1; // TODO: Extract from authentication
        return ResponseEntity.ok(alertService.getUnreadAlerts(userId));
    }
    
    @PutMapping("/{id}/read")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<MonitoringAlert> markAsRead(@PathVariable Long id) {
        return ResponseEntity.ok(alertService.markAsRead(id));
    }
}

