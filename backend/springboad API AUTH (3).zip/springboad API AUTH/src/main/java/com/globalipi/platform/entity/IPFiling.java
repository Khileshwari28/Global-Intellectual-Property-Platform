package com.globalipi.platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "ip_filings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IPFiling {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Filing number is required")
    @Column(nullable = false, unique = true, length = 100)
    private String filingNumber;
    
    @NotBlank(message = "Type is required")
    @Column(nullable = false, length = 50)
    private String type; // PATENT, TRADEMARK, COPYRIGHT, DESIGN
    
    @Column(length = 200)
    private String title;
    
    @Column(length = 200)
    private String applicant;
    
    @Column(length = 50)
    private String country;
    
    @Column(name = "filing_date")
    private LocalDate filingDate;
    
    @Column(name = "publication_date")
    private LocalDate publicationDate;
    
    @Column(length = 50)
    private String status; // FILED, PUBLISHED, EXAMINED, GRANTED, REJECTED
    
    @Column(columnDefinition = "TEXT")
    private String description;
    
    @Column(name = "monitoring_enabled")
    private Boolean monitoringEnabled = false;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}

