package com.globalipi.platform.repository;

import com.globalipi.platform.entity.IPFiling;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IPFilingRepository extends JpaRepository<IPFiling, Long> {
    
    Optional<IPFiling> findByFilingNumber(String filingNumber);
    
    List<IPFiling> findByType(String type);
    
    List<IPFiling> findByCountry(String country);
    
    List<IPFiling> findByStatus(String status);
    
    List<IPFiling> findByMonitoringEnabledTrue();
    
    @Query("SELECT f FROM IPFiling f WHERE f.title LIKE %:keyword% OR f.description LIKE %:keyword% OR f.applicant LIKE %:keyword%")
    List<IPFiling> searchByKeyword(@Param("keyword") String keyword);
}

