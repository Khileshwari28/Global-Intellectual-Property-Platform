package com.globalipi.platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "patents")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Patent {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Patent number is required")
    @Column(nullable = false, unique = true, length = 100)
    private String patentNumber;
    
    @NotBlank(message = "Title is required")
    @Column(nullable = false, length = 500)
    private String title;
    
    @Column(columnDefinition = "TEXT")
    private String abstractText;
    
    @Column(length = 100)
    private String inventor;
    
    @Column(length = 200)
    private String assignee;
    
    @Column(length = 50)
    private String country;
    
    @Column(name = "filing_date")
    private LocalDate filingDate;
    
    @Column(name = "publication_date")
    private LocalDate publicationDate;
    
    @Column(name = "grant_date")
    private LocalDate grantDate;
    
    @Column(length = 50)
    private String status; // PENDING, GRANTED, EXPIRED, ABANDONED
    
    @Column(name = "ipc_classification", length = 100)
    private String ipcClassification;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}

