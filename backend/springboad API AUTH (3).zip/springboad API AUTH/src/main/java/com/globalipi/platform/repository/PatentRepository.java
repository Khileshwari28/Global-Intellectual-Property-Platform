package com.globalipi.platform.repository;

import com.globalipi.platform.entity.Patent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PatentRepository extends JpaRepository<Patent, Long> {
    
    Optional<Patent> findByPatentNumber(String patentNumber);
    
    List<Patent> findByCountry(String country);
    
    List<Patent> findByStatus(String status);
    
    @Query("SELECT p FROM Patent p WHERE p.title LIKE %:keyword% OR p.abstractText LIKE %:keyword% OR p.inventor LIKE %:keyword%")
    List<Patent> searchByKeyword(@Param("keyword") String keyword);
    
    @Query("SELECT p FROM Patent p WHERE p.assignee LIKE %:assignee%")
    List<Patent> findByAssignee(@Param("assignee") String assignee);
}

