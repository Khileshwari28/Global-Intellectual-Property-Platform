package com.globalipi.platform.service;

import com.globalipi.platform.entity.MonitoringAlert;
import com.globalipi.platform.repository.MonitoringAlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class AlertService {
    
    @Autowired
    private MonitoringAlertRepository alertRepository;
    
    public List<MonitoringAlert> getUserAlerts(Integer userId) {
        return alertRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
    
    public List<MonitoringAlert> getUnreadAlerts(Integer userId) {
        return alertRepository.findByUserIdAndIsReadFalse(userId);
    }
    
    public MonitoringAlert markAsRead(Long id) {
        MonitoringAlert alert = alertRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Alert not found with id: " + id));
        alert.setIsRead(true);
        return alertRepository.save(alert);
    }
    
    public MonitoringAlert createAlert(MonitoringAlert alert) {
        return alertRepository.save(alert);
    }
}

