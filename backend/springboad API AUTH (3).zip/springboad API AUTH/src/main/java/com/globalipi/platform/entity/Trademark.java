package com.globalipi.platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "trademarks")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trademark {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Trademark number is required")
    @Column(nullable = false, unique = true, length = 100)
    private String trademarkNumber;
    
    @NotBlank(message = "Mark text is required")
    @Column(nullable = false, length = 200)
    private String markText;
    
    @Column(length = 200)
    private String owner;
    
    @Column(length = 50)
    private String country;
    
    @Column(name = "filing_date")
    private LocalDate filingDate;
    
    @Column(name = "registration_date")
    private LocalDate registrationDate;
    
    @Column(name = "expiry_date")
    private LocalDate expiryDate;
    
    @Column(length = 50)
    private String status; // PENDING, REGISTERED, EXPIRED, CANCELLED
    
    @Column(name = "nice_classification", length = 100)
    private String niceClassification;
    
    @Column(columnDefinition = "TEXT")
    private String description;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}

