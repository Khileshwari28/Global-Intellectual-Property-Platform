# Global IPI Platform - Backend API

A full-stack web platform designed to help innovators, law firms, and R&D teams monitor global intellectual property activity.

## Overview

This is the backend API for the Global IPI Platform, built with Spring Boot. It provides authentication, IP data management, search capabilities, and monitoring alerts for patents, trademarks, and other IP filings.

## Team Members
- **Jeevan Yogesh** - Backend APIs, Authentication (JWT/OAuth2)

## Features

### Authentication & Authorization
- ✅ User Registration with validation
- ✅ User Login with JWT token generation
- ✅ JWT-based authentication
- ✅ Password encryption using BCrypt
- ✅ Role-based access control (USER, ADMIN, INNOVATOR, LAW_FIRM, R&D_TEAM)
- ✅ CORS configuration for frontend integration

### IP Management
- ✅ Patent management and search
- ✅ Trademark management and search
- ✅ IP Filing tracking
- ✅ Global IP activity monitoring
- ✅ Search functionality across all IP types
- ✅ Country-based filtering

### Monitoring & Alerts
- ✅ IP monitoring system
- ✅ Alert notifications for status changes
- ✅ Deadline tracking
- ✅ User-specific alert management

## Tech Stack

- **Java 17**
- **Spring Boot 3.2.0**
- **Spring Security** - Authentication & Authorization
- **Spring Data JPA** - Database operations
- **MySQL** - Database
- **JWT (jjwt 0.12.3)** - Token-based authentication
- **Maven** - Dependency management
- **Lombok** - Reducing boilerplate code

## Prerequisites

Before running this application, make sure you have:

1. **Java 17** or higher installed
2. **Maven 3.6+** installed
3. **MySQL 8.0+** installed and running
4. **Git** installed (for version control)

## Database Setup

1. Create a MySQL database (or let the application create it automatically):
   ```sql
   CREATE DATABASE global_ipi_platform;
   ```

2. The application will automatically create all tables based on entity definitions:
   - `users` - User accounts
   - `patents` - Patent records
   - `trademarks` - Trademark records
   - `ip_filings` - IP filing records
   - `monitoring_alerts` - User alerts

## Configuration

1. Update `src/main/resources/application.properties` with your MySQL credentials:
   ```properties
   spring.datasource.username=your_username
   spring.datasource.password=your_password
   ```

2. Update the JWT secret key (use a strong random string in production):
   ```properties
   jwt.secret=your-secret-key-change-this-in-production
   ```

3. Configure CORS allowed origins for your frontend:
   ```properties
   cors.allowed-origins=http://localhost:3000,http://localhost:5173
   ```

## Running the Application

### Using Maven

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd "springboad API AUTH"
   ```

2. Build the project:
   ```bash
   mvn clean install
   ```

3. Run the application:
   ```bash
   mvn spring-boot:run
   ```

   Or run the JAR file:
   ```bash
   java -jar target/global-ipi-platform-1.0.0.jar
   ```

The application will start on `http://localhost:8080`

## API Endpoints

### Authentication Endpoints

#### 1. Register User
- **URL:** `POST /api/auth/register`
- **Headers:** `Content-Type: application/json`
- **Request Body:**
  ```json
  {
    "username": "john_doe",
    "email": "john@example.com",
    "password": "password123",
    "role": "INNOVATOR"
  }
  ```
- **Roles:** USER, ADMIN, INNOVATOR, LAW_FIRM, R&D_TEAM

#### 2. Login
- **URL:** `POST /api/auth/login`
- **Headers:** `Content-Type: application/json`
- **Request Body:**
  ```json
  {
    "usernameOrEmail": "john_doe",
    "password": "password123"
  }
  ```

#### 3. Validate Token
- **URL:** `GET /api/auth/validate`
- **Headers:** `Authorization: Bearer <token>`

### IP Management Endpoints

#### 4. Get All Patents
- **URL:** `GET /api/ip/patents`
- **Headers:** `Authorization: Bearer <token>`

#### 5. Search Patents
- **URL:** `GET /api/ip/patents/search?keyword=technology`
- **Headers:** `Authorization: Bearer <token>`

#### 6. Get Patents by Country
- **URL:** `GET /api/ip/patents/country/{country}`
- **Headers:** `Authorization: Bearer <token>`

#### 7. Get All Trademarks
- **URL:** `GET /api/ip/trademarks`
- **Headers:** `Authorization: Bearer <token>`

#### 8. Search Trademarks
- **URL:** `GET /api/ip/trademarks/search?keyword=brand`
- **Headers:** `Authorization: Bearer <token>`

#### 9. Get All IP Filings
- **URL:** `GET /api/ip/filings`
- **Headers:** `Authorization: Bearer <token>`

#### 10. Create IP Filing
- **URL:** `POST /api/ip/filings`
- **Headers:** `Authorization: Bearer <token>`
- **Request Body:**
  ```json
  {
    "filingNumber": "US2024001234",
    "type": "PATENT",
    "title": "Innovative Technology",
    "applicant": "Tech Corp",
    "country": "US",
    "filingDate": "2024-01-15",
    "status": "FILED"
  }
  ```

#### 11. Enable Monitoring
- **URL:** `PUT /api/ip/filings/{id}/monitor`
- **Headers:** `Authorization: Bearer <token>`

### Alert Endpoints

#### 12. Get User Alerts
- **URL:** `GET /api/alerts`
- **Headers:** `Authorization: Bearer <token>`

#### 13. Get Unread Alerts
- **URL:** `GET /api/alerts/unread`
- **Headers:** `Authorization: Bearer <token>`

#### 14. Mark Alert as Read
- **URL:** `PUT /api/alerts/{id}/read`
- **Headers:** `Authorization: Bearer <token>`

## Database Schema

### Users Table
| Column      | Type      | Constraints           |
|-------------|-----------|-----------------------|
| id          | INT       | PRIMARY KEY, AUTO_INCREMENT |
| username    | VARCHAR(50) | NOT NULL, UNIQUE      |
| email       | VARCHAR(100) | NOT NULL, UNIQUE      |
| password    | VARCHAR   | NOT NULL (encrypted)  |
| role        | VARCHAR(50) | NOT NULL              |
| created_at  | DATETIME  | NOT NULL              |

### Patents Table
| Column      | Type      | Description           |
|-------------|-----------|-----------------------|
| id          | BIGINT    | PRIMARY KEY           |
| patent_number | VARCHAR(100) | UNIQUE           |
| title       | VARCHAR(500) |                    |
| abstract_text | TEXT    |                       |
| inventor    | VARCHAR(100) |                    |
| assignee    | VARCHAR(200) |                    |
| country     | VARCHAR(50) |                      |
| filing_date | DATE      |                       |
| status      | VARCHAR(50) |                       |

### Trademarks Table
| Column      | Type      | Description           |
|-------------|-----------|-----------------------|
| id          | BIGINT    | PRIMARY KEY           |
| trademark_number | VARCHAR(100) | UNIQUE      |
| mark_text   | VARCHAR(200) |                    |
| owner       | VARCHAR(200) |                    |
| country     | VARCHAR(50) |                      |
| status      | VARCHAR(50) |                       |

### IP Filings Table
| Column      | Type      | Description           |
|-------------|-----------|-----------------------|
| id          | BIGINT    | PRIMARY KEY           |
| filing_number | VARCHAR(100) | UNIQUE        |
| type        | VARCHAR(50) | PATENT, TRADEMARK, etc. |
| title       | VARCHAR(200) |                    |
| applicant   | VARCHAR(200) |                    |
| country     | VARCHAR(50) |                      |
| status      | VARCHAR(50) |                       |
| monitoring_enabled | BOOLEAN |                |

## User Roles

- **USER** - Basic user access
- **ADMIN** - Full administrative access
- **INNOVATOR** - For individual innovators and startups
- **LAW_FIRM** - For law firms managing IP portfolios
- **R&D_TEAM** - For R&D teams monitoring IP activity

## Security Features

1. **Password Encryption:** All passwords are encrypted using BCrypt
2. **JWT Tokens:** Secure token-based authentication with configurable expiration
3. **CORS:** Configured to allow requests from frontend applications
4. **Role-Based Access:** Different roles for different user types
5. **Input Validation:** Request validation using Jakarta Validation

## Testing the API

### Using cURL

**Register:**
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "innovator1",
    "email": "innovator@example.com",
    "password": "password123",
    "role": "INNOVATOR"
  }'
```

**Login:**
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "usernameOrEmail": "innovator1",
    "password": "password123"
  }'
```

**Search Patents:**
```bash
curl -X GET "http://localhost:8080/api/ip/patents/search?keyword=AI" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Project Structure

```
src/
├── main/
│   ├── java/
│   │   └── com/
│   │       ├── globalipi/platform/
│   │       │   ├── PlatformApplication.java
│   │       │   ├── config/
│   │       │   │   └── SecurityConfig.java
│   │       │   ├── controller/
│   │       │   │   ├── AuthController.java
│   │       │   │   ├── IPController.java
│   │       │   │   └── AlertController.java
│   │       │   ├── dto/
│   │       │   │   ├── AuthResponse.java
│   │       │   │   ├── LoginRequest.java
│   │       │   │   └── RegisterRequest.java
│   │       │   ├── entity/
│   │       │   │   ├── User.java
│   │       │   │   ├── Patent.java
│   │       │   │   ├── Trademark.java
│   │       │   │   ├── IPFiling.java
│   │       │   │   └── MonitoringAlert.java
│   │       │   ├── repository/
│   │       │   │   ├── UserRepository.java
│   │       │   │   ├── PatentRepository.java
│   │       │   │   ├── TrademarkRepository.java
│   │       │   │   ├── IPFilingRepository.java
│   │       │   │   └── MonitoringAlertRepository.java
│   │       │   ├── security/
│   │       │   │   └── JwtAuthenticationFilter.java
│   │       │   ├── service/
│   │       │   │   ├── CustomUserDetailsService.java
│   │       │   │   ├── UserService.java
│   │       │   │   ├── IPService.java
│   │       │   │   └── AlertService.java
│   │       │   └── util/
│   │       │       └── JwtUtil.java
│   │       └── springboard/api/auth/ (legacy auth code)
│   └── resources/
│       └── application.properties
└── pom.xml
```

## Git Setup

To push this project to GitHub:

1. Initialize git repository (if not already done):
   ```bash
   git init
   ```

2. Add all files:
   ```bash
   git add .
   ```

3. Commit the changes:
   ```bash
   git commit -m "Initial commit: Global IPI Platform Backend API"
   ```

4. Create a repository on GitHub and add remote:
   ```bash
   git remote add origin <your-github-repo-url>
   ```

5. Push to GitHub:
   ```bash
   git branch -M main
   git push -u origin main
   ```

## Future Enhancements

- [ ] OAuth2 integration (Google, GitHub, etc.)
- [ ] Refresh token mechanism
- [ ] Email verification
- [ ] Password reset functionality
- [ ] Integration with external IP databases (USPTO, WIPO, etc.)
- [ ] Advanced search with filters
- [ ] IP analytics and reporting
- [ ] Automated monitoring and alert generation
- [ ] API documentation with Swagger/OpenAPI
- [ ] Rate limiting
- [ ] Caching for improved performance

## License

This project is part of the Global IPI Platform development.

## Contact

For questions or issues, contact the development team.
